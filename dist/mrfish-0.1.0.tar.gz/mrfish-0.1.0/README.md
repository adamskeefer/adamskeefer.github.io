# audio-labeler
Python Script that renames audio files to their matching Roll, Scene, and Take. Useful for film sets
